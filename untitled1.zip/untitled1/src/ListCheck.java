import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class ListCheck {
    public static void main(String[]args){
        List<Student> list = new ArrayList<>();
        list.add(new Student("debi","pune",39));
        list.add(new Student("neha","mumbai",35));
        list.add(new Student("kirti","pune",47));


        /*List<Student> list1= new ArrayList<>();
        list1.add(new Student("kirti","mumbai"));
        list1.add(new Student("sipu","punjab"));
*/
       /* List<String> pune = list.stream().filter(n -> n.getCity().startsWith("p")).sorted(Comparator.comparing(Student::getName).reversed()).map(Student::getName).collect(Collectors.toList());
        System.out.println(pune);*/
     /* List<String> st = list.stream().map(n->n.getName()).distinct().collect(Collectors.toList());
      System.out.println(st);*/

//        Optional<String> s = list.stream().filter(n -> n.getMarks() > 30).min(Comparator.comparing(Student::getMarks)).map(Student::getName);
//        System.out.println(s);

       // Student reduce = list.stream().reduce(0, (x, y) -> x.getMarks() + y.getMarks(),Integer::sum);
    }
}
