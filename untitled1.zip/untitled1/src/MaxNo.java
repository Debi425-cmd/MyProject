import java.util.Comparator;
import java.util.stream.Stream;

public class MaxNo {
    public static void main(String[]args){
        int a[] = {10,20,30,15,25};
        //Stream.of(a).max();
    }
}
