import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class reverseString {

    public static void main(String[]args){
        List<Character> list = Arrays.asList('a', 'b', 'c');
        List<Character> list1 = Arrays.asList('f', 'g');
        List<Character> collect = Stream.of(list, list1).flatMap(List::stream).collect(Collectors.toList());
System.out.println(collect);
    }


}
