import java.util.Arrays;

public class Anagram {
    public static void main(String[]args){
        String str1 = "debi";
        String str2 = "debi";
        char[] charArray = str1.toCharArray();
        char[] charArray1 = str2.toCharArray();
        Arrays.sort(charArray);
        Arrays.sort(charArray1);
        boolean equals = Arrays.equals(charArray, charArray1);
        System.out.println(equals);
    }
}


