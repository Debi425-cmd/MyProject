import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.stream.Stream;

public class ReverseWord {
    public static void main(String[] args) {
        String str = "i love my country";
        String rev = " ";
        String[] s = str.split(" ");
        for (int i = s.length - 1; i >= 0; i--) {
            rev += s[i] + " ";
        }
        System.out.println(rev);
    }
}
