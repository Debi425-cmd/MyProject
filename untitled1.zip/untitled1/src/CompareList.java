import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class CompareList {

    public static void main(String[] args) {
        List<Student> list = new ArrayList<>();
        list.add(new Student("debi", "pune", 39));
        list.add(new Student("neha", "mumbai", 35));
        list.add(new Student("kirti", "pune", 47));
        list.add(new Student("debi", "pune", 40));
        List<String> collect = list.stream().sorted(Comparator.comparing(Student::getName).thenComparing(Student::getMarks)).map(Student::getName).collect(Collectors.toList());
        System.out.println(collect);
        /*Collections.sort(list, Comparator.comparing(Student::getName));
        System.out.println(list);*/
        /*Comparator<Student> byName = (x,y)->x.getName().compareTo(y.getName());
        //Comparator<Student> byMarks = (r,s)->Integer.compare(r.getMarks(),s.getMarks());
        //List<Student> collect = list.stream().sorted(byName).collect(Collectors.toList());


        /*List<Student> list1 = new ArrayList<>();
        list1.add(new Student("debi", "mumbai", 23));
        list1.add(new Student("hari", "pune", 67));
        list1.add(new Student("kirti", "pune", 47));
        int count;
        for (Student st : list) {
            count=0;
            for (Student st1 : list1) {
                if (st.getName() == st1.getName()) {
                    count++;


                }

            }
            if(count>=1){
                System.out.println(st);
            }


        }

*/
    }

}


